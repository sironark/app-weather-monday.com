export const colorsOfWeather = {
    Clear: '#EC6E4C',
    Clouds: '#545454',
    Rain: '#293e93',
    Snow: '#bfbfbf',
    Thunderstorm: '#5b3087',
    Drizzle: '#47b5e0',
    Mist: '#8c8c8c'
}