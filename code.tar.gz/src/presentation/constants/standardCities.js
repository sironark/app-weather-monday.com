export const standardLat = -22.911;
export const standardLon = -43.2094;